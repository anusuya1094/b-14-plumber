#!/bin/bash -e

DIR=$(dirname "${BASH_SOURCE[0]}") ; . $DIR/env.sh

: "${VAULT_TOKEN:=$(/$INST/get-vault-token.sh)}"
export VAULT_TOKEN

PID=$$

$DIR/create-logstash-config.sh > /tmp/logstash.conf.$$

mv /tmp/logstash.conf.$$ /$INST/logstash.conf
