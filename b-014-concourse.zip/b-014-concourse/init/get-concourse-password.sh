#!/bin/bash -e

# shellcheck source=/dev/null
DIR=$(dirname "${BASH_SOURCE[0]}"); . "$DIR"/env.sh

CONCOURSE_TEAMNAME=$1
VAULT_TEAM_PATH="${CONCOURSE_NAME}/${CONCOURSE_TEAMNAME}"

if [ -z "$CONCOURSE_TEAMNAME" ] ; then
   echo -e "Team name argument missing. Syntax: $0 <team_name>" 1>&2
   exit 1
fi

[ -z "$CONCOURSE_PASSWORD" ] \
  && /"$INST"/vault-secret.sh "$VAULT_TEAM_PATH"/concourse-password \
  || echo "$CONCOURSE_PASSWORD"

