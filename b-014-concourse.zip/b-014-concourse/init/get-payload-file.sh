#!/bin/bash -e

DIR=$(dirname "${BASH_SOURCE[0]}")

file=$1
config=$2
runtime=$3

ARN=$(aws sts get-caller-identity | jq -r '.Arn')

info=$(cat << EOF
  "info": {
EOF
)

[ -n "$runtime" ] && runtime=$(cat << EOF
"runtime": "base64:$runtime",
EOF
)

[ -n "$config" ]  && config=$( cat << EOF
"config":  "base64:$config"
EOF
)

info=""
[ -n "$runtime" ] && info="$runtime"
[ -n "$runtime" ] && [ -n "$config" ] && info="$info,
  "
[ -n "config" ]   && info="$info$config"

payload=$(cat << EOF
{
  "info": {
    $info
  },
  "metadata": {
    "org_scope":      "$ORG_SCOPE",
    "func_scope":     "$FUNC_SCOPE",
    "environment":    "$ENVIRONMENT",
    "account_nr":     "$ACCOUNT_NR",
    "module_name":    "$MODULE_NAME",
    "concourse_team": "$CONTEXT",
    "stage":          "$STAGE",
    "arn":            "$ARN"
  }
}
EOF
)

echo "$payload" > $file
