#!/bin/bash -e

apt-get update          > /dev/null 2>&1
apt-cache search source > /dev/null 2>&1
apt-get install -y      \
  awscli                \
  curl                  \
  gcc                   \
  make                  \
  ruby                  \
  wget                  \
  tar                   \
  zip                   \
> /dev/null 2>&1

wget https://github.com/stedolan/jq/releases/download/jq-1.6/jq-linux64 \
  -O /usr/bin/jq > /dev/null 2>&1
chmod a+x /usr/bin/jq

mkdir /var/log/concourse
