#!/bin/bash -e
echo -n > $2
while IFS='' read -r line || [[ -n "$line" ]]; do
  echo fly -t "$CONCOURSE_TEAMNAME" destroy-pipeline --pipeline=$line --non-interactive >> $2
done < "$1"
