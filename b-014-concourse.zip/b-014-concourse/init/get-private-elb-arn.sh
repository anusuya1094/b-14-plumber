#!/bin/bash -e

aws elb describe-load-balancers \
  --load-balancer-names "$PRIVATE_LOADBALANCER_NAME" \
| jq -r '
  .[][].ListenerDescriptions[]
  | select(.Listener.Protocol=="HTTPS")
  | .Listener.SSLCertificateId
'
