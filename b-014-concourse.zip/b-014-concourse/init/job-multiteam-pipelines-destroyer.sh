#!/bin/bash -e

DIR=$(dirname "${BASH_SOURCE[0]}") ;
# shellcheck source=/dev/null
. "$DIR"/env.sh

TEAMS=$(python3 "$DIR"/teams.py 2> /dev/null)

for team in $TEAMS ; do
  echo "$(date) Running pipelines-destroyer for team $team"
  "$DIR"/pipelines-destroyer.sh "$team"
done
