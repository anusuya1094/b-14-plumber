#!/bin/bash -e

DIR=$(dirname "${BASH_SOURCE[0]}")

# shellcheck source=/dev/null
. "$DIR"/env.sh

CONCOURSE_ADMIN_PASSWORD=$(
  "$DIR"/vault-secret.sh "$VAULT_CONCOURSE_PATH"/concourse-admin-password
)

echo "$CONCOURSE_ADMIN_PASSWORD"
