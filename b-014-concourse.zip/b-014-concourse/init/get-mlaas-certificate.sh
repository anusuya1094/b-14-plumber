#!/bin/bash -e

DIR=$(dirname "${BASH_SOURCE[0]}")

MLAAS_ENDPOINT_HOST=${1:-$("$DIR"/get-mlaas-endpoint-host.sh)}



# download certificate (should be taken from a place more trustworthy)
#
echo -n \
|  openssl s_client -connect "${MLAAS_ENDPOINT_HOST}"     \
|& sed -ne '/-BEGIN CERTIFICATE-/,/-END CERTIFICATE-/p' \
>  /usr/local/share/ca-certificates/mlaas.crt

update-ca-certificates
