#!/bin/bash -ex

shopt -s extglob
DIR=$(dirname "${BASH_SOURCE[0]}")
# shellcheck source=/dev/null
. "$DIR"/env.sh

ARN="$1"
URL="${2:-$CONCOURSE_PRIVATE_DNS}"
TTL="${3:-168h}"   # default TTL is 7 days

: "${AWS_DEFAULT_REGION:=$(/"$INST"/get-default-region.sh)}"
export AWS_DEFAULT_REGION


if [ $ORG_SCOPE != "bp" ] && [ $ORG_SCOPE != "pp" ] && [ $ORG_SCOPE != "gs" ] && [ $MODULE_NAME == "platformserver" ]; then
  "$DIR"/issue-certificate.sh "$URL" "$TTL"
  ARN=$("$DIR"/import-certificate.sh "$URL" "$ARN")
else
  ARN=$("$DIR"/get-privateca-cert.sh "$ARN")
fi

echo "$ARN"

exit 0
