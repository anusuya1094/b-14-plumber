#!/bin/bash -e

CONCOURSE_TSA_HOST=$(
  aws elb describe-load-balancers \
    --load-balancer-names "$MODULE_NAME-$ENVIRONMENT-priv" \
    --query 'LoadBalancerDescriptions[0].DNSName' \
    --output text
)

echo "$CONCOURSE_TSA_HOST"
