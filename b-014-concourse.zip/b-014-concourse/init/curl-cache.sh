#!/bin/bash -ex

[ -z "${STANDARD_BUCKET}" ] && exit 1

URL=${!#}
ARTIFACT=${URL##*/}
DOWNLOAD=0

aws s3 ls s3://"${STANDARD_BUCKET}"/artifacts/$ARTIFACT > /temp/ls-$ARTIFACT || DOWNLOAD=1

echo "/temp/ls-$ARTIFACT"

if [ $DOWNLOAD -eq 1 ] ; then
  curl -s -LO --fail "$@" || exit $?
  aws s3 cp $ARTIFACT s3://${STANDARD_BUCKET}/artifacts/$ARTIFACT || exit $?
else
  aws s3 cp s3://${STANDARD_BUCKET}/artifacts/$ARTIFACT $ARTIFACT || exit $?
fi
