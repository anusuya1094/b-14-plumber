#!/bin/bash -e

DIR=$(dirname "${BASH_SOURCE[0]}")

POSTGRES_HOST=${1:-$("$DIR"/get-postgres-host.sh)}
export POSTGRES_HOST
PGPASSWORD=$("$DIR"/get-postgres-master-password.sh)
export PGPASSWORD

psql -h "$POSTGRES_HOST" -d atc -U master << EOF | awk '/^id/ {print $3}'
\x
SELECT id from pipelines ORDER BY id;
EOF
