#!/bin/bash -e

aws sts get-caller-identity | jq -r '.Account'
