#!/bin/bash -e

shopt -s extglob
key=${1##+(/)}
value=$2

: "${VAULT_TOKEN:=$(/"$INST"/get-vault-token.sh)}"
export VAULT_TOKEN

vault write "$key" value="$value" > /dev/null
