#!/bin/bash -e

aws s3 ls s3://"${STANDARD_BUCKET}" > /dev/null 2>&1 || \
aws s3 mb s3://"${STANDARD_BUCKET}" --region "${AWS_REGION}"

aws s3api put-bucket-versioning \
  --bucket "${STANDARD_BUCKET}"   \
  --versioning-configuration Status=Enabled
