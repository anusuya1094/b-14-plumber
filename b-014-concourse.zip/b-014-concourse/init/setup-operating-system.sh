#!/bin/bash -e

# increase limit for number of open files (default: 1024)
#
ulimit -n 8192

# Set the variables for your environment
#
sed -i "1 a 127.0.1.1 $(hostname)" /etc/hosts

## Firewall settings
ufw allow 2222
ufw allow 8080
ufw default allow routed
