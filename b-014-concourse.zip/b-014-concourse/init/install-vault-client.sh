#!/bin/bash -e

# Installing Vault Client
#

DIR=$(dirname "${BASH_SOURCE[0]}")
VAULT_ZIP=${VAULT_DOWNLOAD_URL##*/}

$DIR/curl-cache.sh -k $VAULT_DOWNLOAD_URL || exit $?

unzip -o -d /usr/sbin "$VAULT_ZIP"
rm "$VAULT_ZIP"
