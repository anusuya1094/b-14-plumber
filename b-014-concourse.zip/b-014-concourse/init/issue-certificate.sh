#!/bin/bash -e

DIR=$(dirname "${BASH_SOURCE[0]}")

URL=$1
TTL=$2

name=${URL%%.*}
domain=${URL#*.}

"$DIR"/pki-role.sh     "$name" "$domain" "$TTL"
"$DIR"/pki-get-cert.sh "$name" "$URL"
