#!/bin/bash

# shellcheck source=/dev/null
DIR=$(dirname "${BASH_SOURCE[0]}") ; . "$DIR"/env.sh
export PATH="$PATH:$DIR"

CONCOURSE_ADMIN_PASSWORD=$("$DIR"/get-concourse-admin-password.sh)
export CONCOURSE_ADMIN_PASSWORD
export HOME=/root

cat <<-EOH | python3 /"$INST"/concourse-execute-in-team-environments.py
#
# These commands are iterated per each created team
#
logx /$INST/concourse-start-team-generator-pipeline.sh \$CONCOURSE_TEAMNAME
EOH
