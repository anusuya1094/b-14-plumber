#!/bin/bash -e

zip -r install.zip \
  config/teams-"$OS_STAGE".yaml \
  config/platform.cfg \
  config/pre-set.cfg \
  config/default.cfg \
  config/crt-revisions.cfg \
  config/"$OS_STAGE".cfg \
  config/post-set.cfg \
  config/RELEASE \
  config/*.tmpl \
  "$INST" \
  test

[ -n "$RESOURCE_TAG" ] && zip install.zip config/"$RESOURCE_TAG".cfg

aws s3 cp install.zip s3://"${STANDARD_BUCKET}"/install.zip > /dev/null
aws s3 ls s3://"${STANDARD_BUCKET}"/install.zip
