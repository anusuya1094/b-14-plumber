#!/bin/bash -e

shopt -s extglob

DOMAIN_NAME=$1

arn=$(
  aws acm list-certificates \
  --query "CertificateSummaryList[ ? DomainName == '"$DOMAIN_NAME"' ].CertificateArn" \
  --output text
)

[ -n "$arn" ] && exit 0

arn=$(
  aws acm request-certificate \
  --domain-name "$DOMAIN_NAME" \
  --validation-method DNS \
  | jq -r .CertificateArn
)

rr=$(
  aws acm describe-certificate \
  --certificate-arn $arn \
  | jq '.Certificate.DomainValidationOptions[0].ResourceRecord'
)

name=$( echo "$rr" | jq -r .Name)
type=$( echo "$rr" | jq -r .Type)
value=$(echo "$rr" | jq -r .Value)

create_statement=$(cat << EOF
{
  "Changes": [
    {
      "Action": "CREATE",
      "ResourceRecordSet": {
        "Name": "$name",
        "Type": "$type",
        "TTL": 300,
        "ResourceRecords": [
          {
            "Value": "$value"
          }
        ]
      }
    }
  ]
}
EOF
)

# TODO: OPEN QUESTION: which zone?
#
#aws route53 change-resource-record-sets --hosted-zone-id Z1B2XDRDYQWWM2 --change-batch file:///tmp/create
