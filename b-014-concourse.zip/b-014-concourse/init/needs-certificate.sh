#!/bin/bash -ex

DIR=$(dirname "${BASH_SOURCE[0]}")

LOOK_AHEAD="${1:-$CERTIFICATE_LOOK_AHEAD}"

"$DIR"/has-private-loadbalancer.sh || exit 0

arn=$("$DIR"/get-private-elb-arn.sh)

echo "$arn"

[ -z "$arn" ] && exit 0

now=$(date +%s)

expiration_date=$(
  aws acm describe-certificate --certificate-arn "$arn" \
  | jq -r '.Certificate.NotAfter'
)

expiration_date=$(date -d "$expiration_date" '+%s')

# if [ $expiration_date -le 0 -o $expiration_date -gt `date +%s` ]
# then
#   echo "expiration date format is epoch"
# # else
# #   expiration_date=$(date -d "$expiration_date" '+%s')
# fi

delta=$((expiration_date - now))

days_to_expiry=$((delta / 86400))

[ $days_to_expiry -lt "$LOOK_AHEAD" ] && {
  (>&2 echo "cert for $PRIVATE_LOADBALANCER_NAME expires in $days_to_expiry days")
  exit 0
}

exit 1
