#!/bin/bash -ex

CERT_ARN=$1

aws elb set-load-balancer-listener-ssl-certificate \
  --load-balancer-name "$PRIVATE_LOADBALANCER_NAME" \
  --load-balancer-port 443 \
  --ssl-certificate-id "$CERT_ARN" \
|| exit $?

echo "cert \"$CERT_ARN\" attached to elb \"$PRIVATE_LOADBALANCER_NAME\""
