#!/bin/bash

# SC2034: DIR appears unused. Verify use (or export if used externally).
# DIR=$(dirname "${BASH_SOURCE[0]}")

echo "$CRT_REVISIONS" | jq -r '
  . | to_entries[] | select(.key == "'"$1"'") | .value
'
