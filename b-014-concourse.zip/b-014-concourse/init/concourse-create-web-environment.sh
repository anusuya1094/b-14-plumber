#!/bin/bash -e

# shellcheck source=/dev/null
DIR=$(dirname "${BASH_SOURCE[0]}"); . "$DIR"/env.sh

export POSTGRES_HOST=$CONCOURSE_RDS_DNSNAME
export POSTGRES_PORT=5432

CONCOURSE_ADMIN_PASSWORD=$("$DIR"/get-concourse-admin-password.sh)
export CONCOURSE_ADMIN_PASSWORD
POSTGRES_MASTER_PASSWORD=$("$DIR"/get-postgres-master-password.sh)
export POSTGRES_MASTER_PASSWORD

MASTER_PIPELINE_TOKEN=$(
  "$DIR"/vault-read.sh "$VAULT_CONCOURSE_PATH"/master-pipeline-token
)
export MASTER_PIPELINE_TOKEN

OAUTH_CLIENT_ID=$("$DIR"/get-oauth-client-id.sh)
export OAUTH_CLIENT_ID
OAUTH_CLIENT_SECRET=$("$DIR"/get-oauth-client-secret.sh)
export OAUTH_CLIENT_SECRET

DEPLOYMENT_DATE=$(date +%F)
export DEPLOYMENT_DATE

# Web Environment Configuration
#
CONCOURSE_ADD_LOCAL_USER=$("$DIR"/concourse-create-local-users.sh)
export CONCOURSE_ADD_LOCAL_USER
CONCOURSE_PRIVATE_IP=$(
  curl \
    --max-time 600 \
    --connect-timeout 600 \
    http://169.254.169.254/latest/meta-data/local-ipv4
)
export CONCOURSE_PRIVATE_IP

envsubst < "$DIR"/../config/web_environment.tmpl | tee /etc/concourse/web_environment
