#!/bin/bash

# shellcheck source=/dev/null
DIR=$(dirname "${BASH_SOURCE[0]}") ; . "$DIR"/env.sh

MASTER_PIPELINE_TOKEN=$("$DIR"/get-vault-token.sh "$TOKEN_LONG_LEASE") || exit $?

"$DIR"/vault-write.sh "$VAULT_CONCOURSE_PATH"/master-pipeline-token "$MASTER_PIPELINE_TOKEN"

teams=$(python3 "$DIR"/teams.py 2> /dev/null)

for team in $teams ; do
  "$DIR"/concourse-create-team-secrets.sh "$team"
  [ "$VAULT_SOURCE_PREFIX" != "$VAULT_DESTINATION_PREFIX" ] \
  && "$DIR"/concourse-copy-team-secrets.sh "$team" \
  || continue
done
