#!/bin/bash -e

export HOME=/root

DIR=$(dirname "${BASH_SOURCE[0]}")

bash "$DIR"/concourse-admin-login.sh list-workers > /dev/null 2>&1

fly --target list-workers workers

bash "$DIR"/concourse-logout.sh      list-workers > /dev/null 2>&1
