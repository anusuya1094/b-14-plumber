#!/bin/bash -e

SCRIPT=$1

BASE=$(basename "$SCRIPT")
BASE=/var/log/concourse/${BASE%%\.sh}

LOGFILE=$BASE.log
STATUSFILE=$BASE.status

logs    "$*" >> "$LOGFILE" 2>&1

set +e
bash -e  $@  >> "$LOGFILE" 2>&1
STATUS=$?
set -e

logd    "$*" >> "$LOGFILE" 2>&1

echo -e "\n\n\n\n\n" >> "$LOGFILE"

echo "$STATUS" > "$STATUSFILE"

exit "$STATUS"
