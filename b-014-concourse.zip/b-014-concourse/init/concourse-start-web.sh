#!/bin/bash -e

DIR=$(dirname "${BASH_SOURCE[0]}")

SERVICE=concourse-web.service

cp /"$INST"/../config/$SERVICE.tmpl /etc/systemd/system/$SERVICE

systemctl start  concourse-web
systemctl enable concourse-web
systemctl status concourse-web

"$DIR"/concourse-admin-login.sh start-web 600
# this serves basically to wait until concourse is up and running
"$DIR"/concourse-logout.sh      start-web
