#!/bin/bash -e

aws elbv2 describe-load-balancers \
  --names "$PUBLIC_LOADBALANCER_NAME" \
> /dev/null 2>&1
