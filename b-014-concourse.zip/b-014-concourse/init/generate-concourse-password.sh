#!/bin/bash

openssl rand 32 -hex
