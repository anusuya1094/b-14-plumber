#!/usr/bin/env python3

import logging
import os
import sys
import yaml



logger  = logging.getLogger()
handler = logging.StreamHandler()

logger.addHandler(handler)
logger.setLevel(logging.DEBUG)



def load_yaml():
    """
    Loads in teams-$ORG_SCOPE-$STAGE.yaml
    :return: dict
    """
    exec_path = os.path.dirname(os.path.abspath(__file__))
    config_file = "{}/../config/teams-{}-{}.yaml".format(
      exec_path,
      os.environ['ORG_SCOPE'],
      os.environ['STAGE']
    )
    logger.debug('Loading in rules from %s' % config_file)
    with open(config_file, 'r') as ymlfile:
        cfg = yaml.load(ymlfile)
    return cfg



if __name__ == '__main__':
    y = load_yaml()
    for t in y['teams']:
        print(t['name'])
