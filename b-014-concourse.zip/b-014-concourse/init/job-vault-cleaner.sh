#!/bin/bash -e

# shellcheck source=/dev/null
DIR=$(dirname "${BASH_SOURCE[0]}") ; . "$DIR"/env.sh

: "${VAULT_TOKEN:=$(/"$INST"/get-vault-token.sh)}"
export VAULT_TOKEN
export POSTGRES_HOST=${1:-$("$DIR"/get-postgres-host.sh)}
export POSTGRES_PORT=${2:-$("$DIR"/get-postgres-port.sh)}
export PGPASSWORD=${3:-$("$DIR"/get-postgres-master-password.sh)}

cd /tmp/vault-cleaner
psql -h "$POSTGRES_HOST" -d atc -U master -o pipelines.txt -q << EOF
\x
SELECT id FROM pipelines ORDER BY id;
EOF

if [ -e "pipelines_ids.txt" ]; then
  cp pipelines_ids.txt oldpipelines_ids.txt

  <pipelines.txt grep -o "| .*" | grep -o "[0-9]*" > pipelines_ids.txt
  ./scripts/list_removed_tables.sh oldpipelines_ids.txt pipelines_ids.txt removed_pipelines_ids.txt

  if [ -s removed_pipelines_ids.txt ]; then
     echo "$(date) some pipelines has been removed" >> vault_cleaner.log

     ./scripts/find_pipeline_names.sh removed_pipelines_ids.txt currentpipelines_short.txt removed_pipelines_names.txt
     cat removed_pipelines_names.txt >> vault_cleaner.log

     sed -e "s#^#/concourse_platform/${CONCOURSE_TEAMNAME}/#" removed_pipelines_names.txt | sed -e 's#$#/#' > vault_paths_to_delete.txt
     echo "$(date) the following secrets will be removed" >> vault_cleaner.log
     cat vault_paths_to_delete.txt >> vault_cleaner.log

     ./scripts/detect_secrets_to_remove.sh vault_paths_to_delete.txt vault-cleaner-commands.sh

     chmod 700 vault-cleaner-commands.sh

     {
       echo "$(date) COMMAND TO BE EXECUTED: "
       cat ./vault-cleaner-commands.sh
       ./vault-cleaner-commands.sh
       echo "$(date) DONE."
     } >> vault_cleaner.log

     rm ./vault-cleaner-commands.sh
  else
     echo "$(date) no pipeline has been removed" >> vault_cleaner.log
  fi
fi

<pipelines.txt  grep -o "| .*" | grep -o "[0-9]*" > pipelines_ids.txt
psql -h "$POSTGRES_HOST" -d atc -U master -o currentpipelines.txt -q << EOF
\x
SELECT concat('%ID%',id, '%ID%', name) FROM pipelines ORDER BY id
EOF
grep '%ID%.*' -o currentpipelines.txt > currentpipelines_short.txt
