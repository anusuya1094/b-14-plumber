#!/bin/bash -e

DIR=$(dirname "${BASH_SOURCE[0]}")

src=${1%%/}
dst=${2%%/}
lvl=${3:-0}

if [ "$lvl" -eq 0 ] ; then
  dst=$dst/${src##*/}
fi

[ -z "$src" ] && exit 1
[ -z "$dst" ] && exit 1

echo "copy from $src to $dst"

: "${VAULT_TOKEN:=$(/"$INST"/get-vault-token.sh)}"
export VAULT_TOKEN

if dir=$(vault list -format=json "$src" 2> /dev/null) ; then
  items=$(echo "$dir" | jq -r -c '.[]')
  for item in $items ; do
    item=${item%/}
    "$DIR"/vault-copy.sh "$src"/"$item" "$dst"/"$item" $((lvl+1)) || exit $?
  done
elif key=$(vault read -format=json "$src" 2> /dev/null) ; then
  value=$(echo "$key" | jq -r .data.value)
  vault write "$dst" value="$value" > /dev/null || exit $?
else
  exit 1
fi
