#!/bin/bash -e

curl https://omnitruck.chef.io/install.sh | sudo bash -s -- -v 4.18.51-1 -P inspec
