#!/bin/bash -e
MAXSIZE=${1:-$SYSLOG_MAXSIZE}

echo maxsize $MAXSIZE
