#!/bin/bash -e

CONCOURSE_TEAMNAME=$1

DIR=$(dirname "${BASH_SOURCE[0]}")

: "${VAULT_TOKEN:=$(/"$INST"/get-vault-token.sh)}"
export VAULT_TOKEN

if [ -z "$CONCOURSE_TEAMNAME" ] ; then
   echo -e "Team name argument missing. Syntax: $0 <team_name>" 1>&2
   exit 1
fi

MASTER_PIPELINE_TOKEN=$(
  "$DIR"/vault-read.sh "$VAULT_CONCOURSE_PATH"/master-pipeline-token
)

VTP="$CONCOURSE_NAME/$CONCOURSE_TEAMNAME"   # "V"ault "T"eam "P"ath

"$DIR"/vault-write.sh  "$VTP"/vault_address         "$VAULT_ADDR"
"$DIR"/vault-write.sh  "$VTP"/concourse-private-dns "$CONCOURSE_PRIVATE_DNS"
"$DIR"/vault-write.sh  "$VTP"/concourse-private-url https://"$CONCOURSE_PRIVATE_DNS"

"$DIR"/vault-write.sh  "$VTP"/concourse-team        "$CONCOURSE_TEAMNAME"
"$DIR"/vault-write.sh  "$VTP"/concourse-username    "$CONCOURSE_TEAMNAME"
"$DIR"/vault-secret.sh "$VTP"/concourse-password

"$DIR"/vault-write.sh  "$VTP"/master-pipeline/vault_token           "$MASTER_PIPELINE_TOKEN"
"$DIR"/vault-write.sh  "$VTP"/master-pipeline/master-pipeline-token "$MASTER_PIPELINE_TOKEN"
