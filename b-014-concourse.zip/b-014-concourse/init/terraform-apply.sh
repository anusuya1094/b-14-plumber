#!/bin/bash -e

#export TF_LOG=INFO 

cd terraform

terraform apply \
  -no-color \
  -lock=true \
  -input=false \
  -auto-approve \
  tfplan
