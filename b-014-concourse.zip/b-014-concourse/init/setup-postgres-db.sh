#!/bin/bash -ex

POSTGRES_DBID="vw-shs-${MODULE_NAME}-${ENVIRONMENT}"
POSTGRES_HOST=$CONCOURSE_RDS_DNSNAME

USER_PASSWORD=$(/"$INST"/get-postgres-password.sh)
MASTER_PASSWORD=$(/"$INST"/get-postgres-master-password.sh)

cat << EOF > /root/.psqlrc
\pset pager off
EOF

# rds.wait just takes too long...
while [ "$db_instance_status" != "available" ] ; do
  sleep 5
  db_instance_status=$(
    aws rds describe-db-instances \
      --db-instance-identifier "$POSTGRES_DBID" \
      --region "$AWS_REGION" \
    | jq -r .DBInstances[0].DBInstanceStatus
  )
done

# Postgres setup
#
aws rds modify-db-instance \
  --db-instance-identifier "$POSTGRES_DBID" \
  --master-user-password "$MASTER_PASSWORD" \
  --region "$AWS_REGION"

export PGPASSWORD="$MASTER_PASSWORD"

# rds.wait just takes too long...
while [ "$db_instance_status" != "available" ] ; do
  sleep 5
  db_instance_status=$(
    aws rds describe-db-instances \
      --db-instance-identifier "$POSTGRES_DBID" \
      --region "$AWS_REGION" \
    | jq -r .DBInstances[0].DBInstanceStatus
  )
done

sleep 5

# Create DB role if not exists
psql -h "$POSTGRES_HOST" -U master -d atc -tAc \
  "SELECT 1 FROM pg_roles WHERE rolname='master'" \
  | grep -q 1 || \
psql -h "$POSTGRES_HOST" -U master -d atc -tAc \
  "CREATE ROLE 'master' WITH PASSWORD '"$USER_PASSWORD"' login"

# Grant permissions for DB
psql -h "$POSTGRES_HOST" -U master -d atc -tAc \
  "GRANT all ON DATABASE atc TO master"
