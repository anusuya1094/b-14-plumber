#!/bin/bash -ex

DIR=$(dirname "${BASH_SOURCE[0]}")

# TS_FORMAT="%Y-%m-%d %H:%M:%S"

URL=$1
ARN=$2

name=${URL%%.*}

"$DIR"/pki-set-acm.sh "$name" "$ARN"    # arn may be empty initially

if [ -z "$ARN" ] ; then
  ARN=$("$DIR"/get-acm-certificates.sh "$URL")
fi

#if [ -n "$ARN" ] ; then
#  ARN=$($DIR/filter-certificates.sh "$ARN" ".*${MODULE_NAME}-${ENVIRONMENT}-priv.*")
#fi

secs=$(
  aws acm describe-certificate --certificate-arn "$ARN" | jq -r '.Certificate.NotAfter'
)

# expiry_date=$(date -d @"$secs" -u +"$TS_FORMAT" 2> /dev/null || date -r "$secs" -u +"$TS_FORMAT")
expiry_date=$(date -d "$secs" +%s)

>&2 echo "new expiry date: $expiry_date"

echo "$ARN"
