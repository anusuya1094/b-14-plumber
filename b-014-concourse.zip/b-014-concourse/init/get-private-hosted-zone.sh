#!/bin/bash -e

CONTEXT=$ORG_SCOPE/$FUNC_SCOPE/$ENVIRONMENT

PRIVATE_HOSTED_ZONE_KEY=/$CONTEXT/bootstrapping/DNS_PRIVATE_HOSTED_ZONE

PRIVATE_HOSTED_ZONE=$(
  aws ssm get-parameter \
    --name "$PRIVATE_HOSTED_ZONE_KEY" \
  | jq -r .Parameter.Value
) || exit $?

echo "$PRIVATE_HOSTED_ZONE"
