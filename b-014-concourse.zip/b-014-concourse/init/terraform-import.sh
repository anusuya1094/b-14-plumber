#!/bin/bash -e

export TF_LOG=INFO

cd terraform
# shellcheck disable=SC2034
IMPORT="terraform import -no-color -lock=true"

#$IMPORT aws_db_subnet_group.default vw-shs-plas-staging-plint
#$IMPORT aws_security_group.concourse sg-0057760c0cd3a57d2
#$IMPORT aws_security_group.rds sg-0fe56f2fb4a3d23b9
#$IMPORT aws_iam_role.concourse rle.pti.sharedservices.plas-staging-runtime.plint
#$IMPORT aws_iam_instance_profile.concourse rle.pti.sharedservices.plas-staging-runtime.plint

terraform show
