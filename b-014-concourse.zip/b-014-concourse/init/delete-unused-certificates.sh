#!/bin/bash

DIR=$(dirname "${BASH_SOURCE[0]}")

URL=$1
ACT=$2

# checks that the ARN that should be in use is not empty.
# this is valuable when the loadbalancer does not exist but we are still running the script at bootstrap.
if [ -z "$ACT" ] ; then
  echo "No in use ARN for the private certificate. The ACT variable is: $ACT"
  exit 0
fi

arns=$("$DIR"/get-acm-certificates.sh "$URL")

echo "found certificate ARNs to be processed: $arns"

for arn in $arns ; do
  [ "$ACT" == "$arn" ] && continue

  echo "$arn is not the same as $ACT. DELETING!"
  aws acm delete-certificate --certificate-arn "$arn" 2> /dev/null || true
done
