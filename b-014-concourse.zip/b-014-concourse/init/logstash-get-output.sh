#!/bin/bash -e

# shellcheck source=/dev/null
DIR=$(dirname "${BASH_SOURCE[0]}") ; . "$DIR"/env.sh

MLAAS_ENDPOINT=$("$DIR"/get-mlaas-endpoint-host.sh)     || exit $?
export MLAAS_ENDPOINT
MLAAS_PASSWORD=$("$DIR"/get-mlaas-endpoint-password.sh) || exit $?
export MLAAS_PASSWORD
MLAAS_USERNAME=$("$DIR"/get-mlaas-user-id.sh)           || exit $?
export MLAAS_USERNAME

envsubst < "$DIR"/../config/logstash-jdbc-output.tmpl
