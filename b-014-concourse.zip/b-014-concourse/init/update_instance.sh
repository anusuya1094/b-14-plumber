#!/bin/bash

#Update the instance
printf '\nUpdating Instance\n'
echo `date`

sudo apt-get install -y awscli
UPDATE=$(apt update)
STATUS=$(apt upgrade -y)
echo $STATUS

if [[ "$STATUS" == *'done'* ]]; then
        TEXT="Instance Update is successful"
elif [[ "$STATUS" == *'0 upgraded'* ]]; then
        TEXT="No Update required"
else
        TEXT="Instance Update failed. Kindly check logs from updateInstanceLog.txt file"
fi
        echo "$TEXT" > /tmp/output_UI.txt 