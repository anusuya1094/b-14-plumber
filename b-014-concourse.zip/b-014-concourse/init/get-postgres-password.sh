#!/bin/bash -e

DIR=$(dirname "${BASH_SOURCE[0]}")

POSTGRES_PASSWORD=$(
  "$DIR"/vault-secret.sh "$VAULT_CONCOURSE_PATH"/postgresql-password
)

echo "$POSTGRES_PASSWORD"
