#!/bin/bash -e
set -x

DIR=$(dirname "${BASH_SOURCE[0]}")

file=$1
config=$2
runtime=$3
echo $runtime

VAULT_PROVISIONER="$ACCOUNT_NR:fnc-$ORG_SCOPE-$FUNC_SCOPE-vault-provisioner-$STAGE"

[ -n "$config"  ] && config=$( echo "$config"  | base64 | tr -d '\n')
[ -n "$runtime" ] && runtime=$(echo "$runtime" | base64 | tr -d '\n')

$DIR/get-payload-file.sh $file "$config" "$runtime"

LAMBDA=$(aws lambda invoke \
  --cli-read-timeout 300 \
  --invocation-type RequestResponse \
  --function-name "$VAULT_PROVISIONER" \
  --cli-binary-format raw-in-base64-out \
  --payload file://$file \
  /dev/stdout
)

ERRORS=$(echo "$LAMBDA" | jq -r '. | select(has("errors")) | select(.errors!=0).messages')

if [ -n "$ERRORS" ] ; then
  echo "VAULT PROVISIONER ERRORS:"
  echo "$ERRORS"
  exit 1
fi
