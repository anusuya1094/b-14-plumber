#!/usr/bin/env python3
import yaml
import os
import logging
import sys
import tempfile
import subprocess
from   teams import load_yaml

def get_stdin():
    shell_script = sys.stdin.readlines()
    return shell_script

def team_yaml_definition_file(team):
    fd, file_path = tempfile.mkstemp()
    content = yaml.dump(team['definition'], explicit_start=True)
    with open(file_path, 'w') as team_yaml:
       team_yaml.write(content)
       team_yaml.close()
    logging.debug('Writing team definition to %s' % file_path)
    return file_path

def fly_run(target, cmd, *args):
    return subprocess.run(
       [ 'fly', '-t', target, cmd, *args ], stdout=subprocess.PIPE, check=True
    )
def concourse_login(username = 'admin' , password = None, team = 'main' , target = 'admin'):
    concourse_url = os.environ.get('CONCOURSE_URL', 'http://127.0.0.1:8080')
    return fly_run(
       target,
       'login',
       '-u', username,
       '-p', password,
       '-n', team,
       '-c', 'http://127.0.0.1:8080'
    )

def concourse_logout():
    return subprocess.run(['fly', 'logout', '-a'] , stdout=subprocess.PIPE, check=True)

def concourse_setup_team(team):
    admin_user = 'admin'
    admin_password = os.environ['CONCOURSE_ADMIN_PASSWORD']
    concourse_login(admin_user, admin_password, 'main', 'admin')
    config_file = team_yaml_definition_file(team)
    run = fly_run(
       'admin',
       'set-team',
       '--team-name', team['name'],
       '--local-user', team['name'],
       '--config', config_file,
       '--non-interactive'
    )
    concourse_logout()
    if os.path.exists(config_file):
       os.remove(config_file)
    return run

logger = logging.getLogger()
handler = logging.StreamHandler()
logger.addHandler(handler)
logger.setLevel(logging.DEBUG)
tmpdir = tempfile.TemporaryDirectory()

y = load_yaml()

scripts = get_stdin()

if 'teams' not in y:
    logger.exception("'teams' array not present in yaml file")
    exit(1)

for team in y['teams']:
    for word in [ 'name', 'trigger_repo_url', 'trigger_repo', 'trigger_repo_project', 'definition' ]:
        if word not in team:
            logger.error("'%s' attribute not present in team definition" % word)
            exit(1)
    os.environ['CONCOURSE_TEAMNAME'] = team.get('name')
    os.environ['TRIGGER_REPO_URL'] = team.get('trigger_repo_url')
    os.environ['TRIGGER_REPO'] = team.get('trigger_repo')
    os.environ['TRIGGER_REPO_PROJECT'] = team.get('trigger_repo_project')
    os.environ['TRIGGER_REPO_REVISION'] = team.get('trigger_repo_revision', 'master')
    os.environ['HOME'] = '/root'
    
    logger.info("Setting up team %s" % team['name'])
    logger.info("-------------------------------------------------")
    concourse_setup_team(team)
    logger.info("Running scripts in target %s context" % team['name'] )

    for ev in [ 'ORG_SCOPE', 'FUNC_SCOPE', 'CONCOURSE_TEAMNAME', 'TRIGGER_REPO_URL', 'TRIGGER_REPO', 'TRIGGER_REPO_PROJECT', 'TRIGGER_REPO_REVISION', 'HOME' ] :
        logger.debug('[TEAM %s] Setting ENV[%s]=%s' % (team['name'], ev, os.environ[ev]))

    for s in scripts:
        logger.info("[TEAM %s] Executing: %s" % (team['name'], s ))
        os.system(s)
