#!/bin/bash -e

[ -z "$1" ] && exit 0

DIR=$(dirname "${BASH_SOURCE[0]}")

CONFIG=$1
FILE="$DIR/../config/${CONFIG}.cfg"

if [ -f "$FILE" ] ; then

  cat << EOF

# [${CONFIG}.cfg]
#
EOF

  envsubst < "$FILE"
fi
