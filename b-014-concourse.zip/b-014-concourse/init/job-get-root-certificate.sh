#!/bin/bash -e

# shellcheck source=/dev/null
DIR=$(dirname "${BASH_SOURCE[0]}"); . "$DIR"/env.sh

: "${AWS_DEFAULT_REGION:=$(/"$INST"/get-default-region.sh)}"
export AWS_DEFAULT_REGION

#--------not required since it was added for non odp platform which has been depricated---------
# if [ $ORG_SCOPE != "bp" ] && [ $ORG_SCOPE != "pp" ] && [ $ORG_SCOPE != "gs" ] && [ $MODULE_NAME == "platformserver" ]; then
#     echo "Org_scope : $ORG_SCOPE and Module name : $MODULE_NAME"
# elif [ $ENVIRONMENT == "dev" ] || [ $ENVIRONMENT == "plint" ]; then
#   wget http://aia.pca.dev.eu.bp.aws.cloud.vwgroup.com/rootcert/root-ca.crt -O root-ca-pca.crt > /dev/null 2>&1
# else
#   wget http://aia.pca.prd.eu.bp.aws.cloud.vwgroup.com/rootcert/root-ca.crt -O root-ca-pca.crt > /dev/null 2>&1
# fi

#--------not required---------
# grep -- '-----BEGIN CERTIFICATE-----' root-ca-pca.crt || {
#   mv root-ca-pca.crt root-ca-pca.b64
#   base64 --decode root-ca-pca.b64 > root-ca-pca.crt
# }

aws ssm get-parameter --name "$VAULT_CA_SSM_PATH" \
   | jq -r .Parameter.Value \
   > root-ca.crt

 grep -- '-----BEGIN CERTIFICATE-----' root-ca.crt || {
  mv root-ca.crt root-ca.b64
  base64 --decode root-ca.b64 > root-ca.crt
}

cp root-ca.crt /usr/local/share/ca-certificates/
# cp root-ca-pca.crt /usr/local/share/ca-certificates/
update-ca-certificates
