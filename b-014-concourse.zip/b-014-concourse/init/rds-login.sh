#!/bin/bash -e

DIR=$(dirname "${BASH_SOURCE[0]}")

POSTGRES_HOST=$("$DIR"/get-postgres-host.sh)         || exit $?
PGPASSWORD=$("$DIR"/get-postgres-master-password.sh) || exit $?

export POSTGRES_HOST PGPASSWORD

psql -h "$POSTGRES_HOST" -d atc -U master
