#!/bin/bash -x

release_version=$(lsb_release -r -s)

if [ $release_version == '16.04' ]
then

    # On the AMI of Ubuntu 16.04 is the snap package installed 
    snap remove amazon-ssm-agent

    # Get the debian package
    wget "https://s3-eu-central-1.amazonaws.com/amazon-ssm-eu-central-1/latest/debian_amd64/amazon-ssm-agent.deb"

    dpkg -i amazon-ssm-agent.deb
    systemctl enable amazon-ssm-agent
    systemctl start amazon-ssm-agent
    systemctl status amazon-ssm-agent.service

else
    # Ubuntu 18.04
    curl "https://s3.amazonaws.com/session-manager-downloads/plugin/latest/ubuntu_64bit/session-manager-plugin.deb" -o "session-manager-plugin.deb"
    dpkg -i session-manager-plugin.deb
    session-manager-plugin
    systemctl enable session-manager-plugin.service
    systemctl start session-manager-plugin.service

fi

