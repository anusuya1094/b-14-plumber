#!/bin/bash -e

ARN=$(
  aws elbv2 describe-load-balancers \
    --names "$PUBLIC_LOADBALANCER_NAME" \
  | jq -r '.[][].LoadBalancerArn'
) || exit $?

echo "$ARN"
