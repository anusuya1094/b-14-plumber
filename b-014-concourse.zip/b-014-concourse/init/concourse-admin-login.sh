#!/bin/bash -e

TARGET=${1:-admin}

export HOME=/root
MAX_WAIT=${2:-30}

DIR=$(dirname "${BASH_SOURCE[0]}")

# shellcheck source=/dev/null
. "$DIR"/env.sh

s=0
a=0
status=1

password=$("$DIR"/get-concourse-admin-password.sh)

while [ $status -ne 0 ] && [ $s -lt "$MAX_WAIT" ] ; do

  set +e

  a=$((a + 1))

  if [ $a -gt 1 ] ; then
    echo -e "\n\nattempt #$a\n"
  fi

  fly --target "$TARGET" login \
      --team-name main \
      --username admin \
      --password "$password" \
      --concourse-url http://127.0.0.1:8080 \
  < /dev/null

  status=$?
  set -e

  [ $status -eq 0 ] && {
    echo -e "\n\nsuccessful after $a attempts"
    exit 0
  }

  sleep 5
  s=$((s + 5))

done

echo -e "\n\nNOT successful after $a attempts"

exit 1
