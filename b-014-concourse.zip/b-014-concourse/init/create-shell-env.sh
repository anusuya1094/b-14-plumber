#!/bin/bash -e

DIR=$(dirname "${BASH_SOURCE[0]}")

# this script is generating a unix shell environment for those processes which
# need to run outside/before terraform of the concourse instance, like e.g. the
# creation of the concourse server certificate before concourse creation from
# codepipeline or during concourse lifetime from a cronjob



# as long as there is nothing better than that, parse MODULE_NAME from
# codebuild variable CODEBUILD_SOURCE_REPO_URL. should actually be passed
# from the bootstrapping pipeline.
#
: "${MODULE_NAME:=${CODEBUILD_SOURCE_REPO_URL##*/}}"
export MODULE_NAME=${MODULE_NAME%%\.zip}



# NOTE: shitty convention as long as branch is not passed from bootstrapping:
# if MODULE_NAME contains '-', use last part behind '-' as branch name, e.g.
# MODULE_NAME == "platformserver-staging" => RESOURCE_TAG = "staging"
#
[ -z "${MODULE_NAME/*-*/}" ] && export RESOURCE_TAG=${MODULE_NAME##*-}



ACCOUNT_NR=$("$DIR"/get-account.sh)
export ACCOUNT_NR
PLATFORM_CONCOURSE_RELEASE=$(cat "$DIR"/../config/RELEASE)
export PLATFORM_CONCOURSE_RELEASE
PRIVATE_HOSTED_ZONE=$("$DIR"/get-private-hosted-zone.sh)
export PRIVATE_HOSTED_ZONE



cat << EOF > "$DIR"/env.sh
# environment configured by create-shell-env.sh
EOF



"$DIR"/add-config.sh pre-set              >> "$DIR"/env.sh
# shellcheck source=./get-config.sh
. "$("$DIR"/get-config.sh pre-set)"



"$DIR"/add-config.sh default              >> "$DIR"/env.sh
# shellcheck source=./get-config.sh
. "$(bash "$DIR"/get-config.sh default)"



"$DIR"/add-config.sh crt-revisions        >> "$DIR"/env.sh
# shellcheck source=./get-config.sh
. "$(bash "$DIR"/get-config.sh crt-revisions)"



# if you want to add to or overwrite some of the before definitions
# for a particular $ORG_SCOPE-$STAGE, add such definitions to
# environments/$ORG_SCOPE-$STAGE.env
#
"$DIR"/add-config.sh "$ORG_SCOPE"-"$STAGE"    >> "$DIR"/env.sh
# shellcheck source=./get-config.sh
. "$("$DIR"/get-config.sh "$ORG_SCOPE"-"$STAGE")"



# if you want to add to or overwrite some of the before definitions
# for a certain $RESOURCE_TAG, add such definitions to
# environments/$RESOURCE_TAG.env
#
"$DIR"/add-config.sh "$RESOURCE_TAG"        >> "$DIR"/env.sh
# shellcheck source=./get-config.sh
. "$("$DIR"/get-config.sh "$RESOURCE_TAG")"



"$DIR"/add-config.sh post-set             >> "$DIR"/env.sh
# shellcheck source=./get-config.sh
. "$("$DIR"/get-config.sh post-set)"
