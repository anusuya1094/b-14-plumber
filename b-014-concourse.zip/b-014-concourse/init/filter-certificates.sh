#!/bin/bash -e

ARNS=$1
# IN_USE_BY is used within jq, but shellcheck doesn't verify it
# shellcheck disable=SC2034
IN_USE_BY=$2

for arn in $ARNS ; do
  aws acm describe-certificate --certificate-arn "$arn" \
  | jq -r '.Certificate | select(
    .InUseBy[] | match("$IN_USE_BY")
  ) | .CertificateArn'
done
