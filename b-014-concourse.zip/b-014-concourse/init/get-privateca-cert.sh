#!/bin/bash -e

DIR=$(dirname "${BASH_SOURCE[0]}")
PRIVATE_CA_LAMBDA="lzms-cert-requester"

envsubst < "$DIR"/../config/privateca-payload.tmpl | tee privateca-cert-create.json > /dev/null 2>&1
LAMBDA=$(aws lambda invoke --function-name $PRIVATE_CA_LAMBDA --cli-binary-format raw-in-base64-out --payload file://privateca-cert-create.json response-pca.json)

CertificateArn=$(cat response-pca.json | jq -r '.CertificateArn')
echo $CertificateArn
