#!/bin/bash -e

export HOME=/root
export PATH=$PATH:/$INST

CONCOURSE_TEAMNAME=$1

if [ -n "$CONCOURSE_TEAMNAME" ] ; then
  OPTION="--target $CONCOURSE_TEAMNAME"
else
  OPTION="-a"
fi

fly logout $OPTION > /dev/null
