#!/bin/bash -e

export HOME=/root
export TOOLNAME=pipelines-destroyer

DIR=$(dirname "${BASH_SOURCE[0]}")

# shellcheck source=/dev/null
. "$DIR"/env.sh

CONCOURSE_TEAMNAME="${1}"

# pipeline-file-paths
ACTUAL_PIPELINES=/tmp/${CONCOURSE_TEAMNAME}-pipelines-destroyer_actual-pipelines.txt
DISCOVERED_PIPELINES=/tmp/${CONCOURSE_TEAMNAME}-pipelines-destroyer_discovered-pipelines.txt
NOT_DISCOVERED_PIPELINES=/tmp/${CONCOURSE_TEAMNAME}-pipelines-destroyer_not-discovered-anymore.txt

# Delete those pipeline files first

rm -f "${ACTUAL_PIPELINES}" "${DISCOVERED_PIPELINES}" "${NOT_DISCOVERED_PIPELINES}"

if [ -z "$CONCOURSE_TEAMNAME" ] ; then
   echo -e "Team name argument missing. Syntax: $0 <team_name>" 1>&2
   exit 1
fi

bash "$DIR"/concourse-login.sh "$CONCOURSE_TEAMNAME" > /dev/null 2>&1

fly --target "$CONCOURSE_TEAMNAME" get-pipeline \
    --pipeline master-pipeline \
    --json | \
    jq '.jobs[].name' | \
    sed 's/Set-And-Trigger-//g' | \
    sed 's/"//g' > "${DISCOVERED_PIPELINES}"

#retrieve all the pipeline on concourse
fly --target "$CONCOURSE_TEAMNAME" pipelines | \
    awk '{print $1}' | \
    grep -v "master-pipeline" | \
    grep -v "generator-pipeline" > "${ACTUAL_PIPELINES}"

"$DIR"/pipelines-destroyer_list-removed.sh "${ACTUAL_PIPELINES}" "${DISCOVERED_PIPELINES}" "${NOT_DISCOVERED_PIPELINES}"

if [ -s "${NOT_DISCOVERED_PIPELINES}" ] ; then
  echo "$(date) [$TOOLNAME] these pipelines are not discovered anymore:"
  cat "${NOT_DISCOVERED_PIPELINES}"

  #to check the last build, if we want to be sure that is not currently used
  #lastbuild=$(fly -t ${CONCOURSE_TEAMNAME} builds --pipeline <PIPELINE_NAME> --count 1 | awk '{print $5}' | sed 's/@.*//g')

  # Why is this function sourced instead of being directly called? Investigate it later
  # The previous version is the commented out line without using the FILEPATH variables
  # shellcheck source=./pipelines-destroyer_prepare-destroy.sh
  . "$DIR"/pipelines-destroyer_prepare-destroy.sh "${NOT_DISCOVERED_PIPELINES}" /tmp/pipelines-destroyer_commands.sh
  #. $DIR/pipelines-destroyer_prepare-destroy.sh /tmp/pipelines_not_discovered_anymore.txt /tmp/pipelines-destroyer_commands.sh
  chmod +x /tmp/pipelines-destroyer_commands.sh
  echo "$(date) [$TOOLNAME] the following command will be executed:"
  cat /tmp/pipelines-destroyer_commands.sh
  /tmp/pipelines-destroyer_commands.sh
  echo "$(date) [$TOOLNAME] pipelines destroyed."
  rm /tmp/pipelines-destroyer_commands.sh
else
  echo "$(date) [$TOOLNAME] no pipelines to destroy"
fi
bash "$DIR"/concourse-logout.sh > /dev/null 2>&1
