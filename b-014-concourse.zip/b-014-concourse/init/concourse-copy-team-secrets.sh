#!/bin/bash

[ "$VAULT_SOURCE_PREFIX" = "$VAULT_DESTINATION_PREFIX" ] && exit 0

TEAM=$1

DIR=$(dirname "${BASH_SOURCE[0]}") ; . $DIR/env.sh

SRC=$VAULT_SOURCE_PREFIX
DST=$VAULT_DESTINATION_PREFIX

for team in $TEAMS ; do
  $DIR/vault-copy.sh $SRC/$TEAM/artifactory-password $DST/$TEAM
  $DIR/vault-copy.sh $SRC/$TEAM/artifactory-username $DST/$TEAM
  $DIR/vault-copy.sh $SRC/$TEAM/git-password $DST/$TEAM
  $DIR/vault-copy.sh $SRC/$TEAM/git-private-key $DST/$TEAM
  $DIR/vault-copy.sh $SRC/$TEAM/git-push-password $DST/$TEAM
  $DIR/vault-copy.sh $SRC/$TEAM/git-push-username $DST/$TEAM
  $DIR/vault-copy.sh $SRC/$TEAM/git-username $DST/$TEAM
done

$DIR/vault-copy.sh $SRC/$TEAM/shared $DST/$TEAM
