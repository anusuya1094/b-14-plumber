#!/bin/bash -e

#export TF_LOG=INFO 

cd terraform

terraform plan \
  -no-color \
  -lock=true \
  -input=false \
  -var-file=env.tfvars \
  -out=tfplan
