#!/bin/bash -e

DIR=$(dirname "${BASH_SOURCE[0]}")

BASTION_PUB_KEY="${1:-$("$DIR"/get-bastion-pub-key.sh)}"

# Add bastion host public key
#
echo "$BASTION_PUB_KEY" > /home/ubuntu/.ssh/authorized_keys

printf "\\nTrustedUserCAKeys /home/ubuntu/.ssh/authorized_keys" >> /etc/ssh/sshd_config

service sshd restart
