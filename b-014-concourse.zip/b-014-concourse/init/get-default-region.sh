#!/bin/bash -e

REGION=$(
  curl -s http://169.254.169.254/latest/dynamic/instance-identity/document \
  | jq .region -r
)

echo "$REGION"
