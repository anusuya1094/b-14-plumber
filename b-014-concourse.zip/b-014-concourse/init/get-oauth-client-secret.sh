#!/bin/bash -e

DIR=$(dirname "${BASH_SOURCE[0]}")

OAUTH_CLIENT_SECRET=$(
  "$DIR"/vault-secret.sh "$VAULT_CONCOURSE_PATH"/oauth-client-secret
)

echo "$OAUTH_CLIENT_SECRET"
