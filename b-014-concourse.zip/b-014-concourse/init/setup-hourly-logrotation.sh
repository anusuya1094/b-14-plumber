#!/bin/bash -e

# change the overall logrotate behavior to be runned hourly
mv /etc/cron.daily/logrotate /etc/cron.hourly

# modify configuration file for additional hourly rotation of syslog, based on filesize
# sed -i "3i $(/init/get-syslog-maxsize.sh)" /etc/logrotate.d/rsyslog

# retrieve the line where to add the constraint on maxsize
SYSLOG_CONF_LINE=$(grep -hnr -C2 "/var/log/syslog" /etc/logrotate.d/rsyslog | grep - | grep -v '{' | sed 's/-.*//g')

# prepare the command for insertion
echo -n 'sed -i "' > /tmp/insert_maxsize.sh
echo -n $SYSLOG_CONF_LINE >> /tmp/insert_maxsize.sh
echo -n 'i $(/init/get-syslog-maxsize.sh)" /etc/logrotate.d/rsyslog' >> /tmp/insert_maxsize.sh
chmod +x /tmp/insert_maxsize.sh

# add the line
/tmp/insert_maxsize.sh
