#!/bin/bash -e

DIR=$(dirname "${BASH_SOURCE[0]}")

API_CLUSTER_ID=$(
  "$DIR"/get-mlaas-secret-from-vault.sh elasticsearch_api_cluster_id
) || exit $?

MLAAS_PORT=$(
  "$DIR"/get-mlaas-secret-from-vault.sh port
) || exit $?

MLAAS_ENDPOINT_HOST=$API_CLUSTER_ID.mlaas.$PRIVATE_HOSTED_ZONE:$MLAAS_PORT

echo "$MLAAS_ENDPOINT_HOST"
