#!/bin/bash -x

exec > >(tee -a /var/log/user-data.log|logger -t user-data -s 2>/dev/console) 2>&1

DIR=$(dirname "${BASH_SOURCE[0]}")
export PATH="$PATH:$DIR"
# shellcheck source=/dev/null
. "$DIR"/env.sh

env | sort

logx /"$INST"/setup-operating-system.sh
logx /"$INST"/set-dns-resolvers.sh
logx /"$INST"/prepare-filesystems.sh

logx /"$INST"/install-ssm-agent.sh
logx /"$INST"/install-bash-login.sh
logx /"$INST"/install-concourse.sh
#logx /"$INST"/install-logstash.sh
logx /"$INST"/install-vault-client.sh

logx /"$INST"/job-get-root-certificate.sh

VAULT_TOKEN=$(/init/get-vault-token.sh)
export VAULT_TOKEN

# logx /"$INST"/get-mlaas-certificate.sh

# logx /"$INST"/create-mlaas-env.sh
# logx /"$INST"/start-mlaas-beats.sh
#logx /"$INST"/start-log-forwarder.sh

logx /"$INST"/put-bastion-pub-key.sh

logx /"$INST"/setup-postgres-db.sh

logx /"$INST"/start-concourse-metrics.sh

logx /"$INST"/create-key-pairs.sh

# see NOTE inside script
logx /"$INST"/concourse-migrate-platform-deployment.sh

logx /"$INST"/concourse-provide-all-secrets.sh
logx /"$INST"/concourse-create-web-environment.sh
logx /"$INST"/concourse-create-unix-user.sh
logx /"$INST"/concourse-start-web.sh
logx /"$INST"/job-prune-stalled-workers.sh
logx /"$INST"/concourse-create-worker-environment.sh
logx /"$INST"/concourse-start-worker.sh
logx /"$INST"/concourse-start-all-generator-pipelines.sh

logx /"$INST"/setup-hourly-logrotation.sh

logx /"$INST"/prepare-pipelines-status-scripts.sh

logx /"$INST"/delete-unused-certificates.sh

logx /"$INST"/setup-cronjobs.sh

#ubuntu 1804 specific changes
rm /etc/resolv.conf
ln -s /run/systemd/resolve/resolv.conf /etc/resolv.conf
systemctl restart systemd-resolved