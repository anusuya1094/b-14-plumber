#!/bin/bash -e

DIR=$(dirname "${BASH_SOURCE[0]}")

TEST_VALUE=$(cat $DIR/../init/setup-operating-system.sh | \
           grep "ulimit -n" | \
           awk '{print $3}')

CONCOURSE_PID=$(ps -fg concourse --no-headers | \
              awk '($3 != 1)' | \
              awk '{print $2}')

CONCOURSE_PROC_FD_SOFT_LIMIT=$(cat /proc/$CONCOURSE_PID/limits | \
                             grep 'Max open files' | \
                             sed 's/Max open files\s*//g' | \
                             sed 's/\s.*//')

[ $CONCOURSE_PROC_FD_SOFT_LIMIT -eq $TEST_VALUE ] && exit 0

exit 1
