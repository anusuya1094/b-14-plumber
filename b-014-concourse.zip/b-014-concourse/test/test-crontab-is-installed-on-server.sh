#!/bin/bash -e

CRONTAB_SIZE=$(crontab -l | wc -c)

[ $CRONTAB_SIZE -eq 0 ] && exit 1

exit 0
