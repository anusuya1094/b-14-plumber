#!/bin/bash -e

df /var/lib/concourse && 
mount | awk '{print $3}' | grep '/var/lib/concourse' &&
exit 0

exit 1
