#!/bin/bash

DIR=$(dirname "${BASH_SOURCE[0]}")

export VAULT_TOKEN=$($DIR/../init/get-vault-token.sh)

MLAAS_ENDPOINT_HOST=$($DIR/../init/get-mlaas-endpoint-host.sh)
MLAAS_ENDPOINT_PASSWORD=$($DIR/../init/get-mlaas-endpoint-password.sh)
MLAAS_USER_ID="beat_writer"

curl \
  --insecure \
  -u $MLAAS_USER_ID:$MLAAS_ENDPOINT_PASSWORD \
  $MLAAS_ENDPOINT_HOST/concourse-plint/_source/1

