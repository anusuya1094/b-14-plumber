#!/bin/bash -e

DIR=$(dirname "${BASH_SOURCE[0]}") ; . $DIR/../init/env.sh

/$INST/concourse-login.sh

fly --target $CONCOURSE_TEAMNAME trigger-job \
    --job    generator-pipeline/big_bang \
    --watch

/$INST/concourse-logout.sh
