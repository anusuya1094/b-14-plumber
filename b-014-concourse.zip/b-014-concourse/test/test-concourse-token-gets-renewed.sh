#!/bin/bash -e

DIR=$(dirname "${BASH_SOURCE[0]}") ; . $DIR/../init/env.sh

VAULT_TOKEN=$(grep CONCOURSE_VAULT_CLIENT_TOKEN /etc/concourse/web_environment)
VAULT_TOKEN=${VAULT_TOKEN##*=}
export VAULT_TOKEN

TEST_PIPELINE=$ORG_SCOPE-$FUNC_SCOPE-platformtest-$ENVIRONMENT
TEST_JOB=master-pipeline/Set-And-Trigger-$TEST_PIPELINE

MASTER_PIPELINE_TOKEN_PATH=$TEAMPATH/master-pipeline/vault_token
VAULT_DEPLOYER_TOKEN_PATH=$TEAMPATH/$TEST_PIPELINE/vault-deployer-token

echo

date
MASTER_PIPELINE_TOKEN=$(vault read $MASTER_PIPELINE_TOKEN_PATH -format=json | jq -r .data.value)
echo "MASTER PIPELINE TOKEN: ***${MASTER_PIPELINE_TOKEN: -4}"
vault token lookup $MASTER_PIPELINE_TOKEN | egrep '^expire'
echo

date
VAULT_DEPLOYER_TOKEN=$(vault read $VAULT_DEPLOYER_TOKEN_PATH -format=json | jq -r .data.value)
echo "VAULT_DEPLOYER TOKEN:  ***${VAULT_DEPLOYER_TOKEN: -4}"
vault token lookup $VAULT_DEPLOYER_TOKEN | egrep '^expire'
echo

$DIR/../init/concourse-login.sh > /dev/null

date
echo "trigger $TEST_JOB"
fly -t $CONCOURSE_TEAMNAME tj -j $TEST_JOB -w > /dev/null
echo

date
echo "sleeping now for 5m..."
echo

sleep 300

date
echo "waking up"
echo

date
echo "trigger $TEST_JOB again"
fly -t $CONCOURSE_TEAMNAME tj -j $TEST_JOB -w > /dev/null
echo

$DIR/../init/concourse-login.sh > /dev/null

MASTER_PIPELINE_TOKEN=$(vault read $MASTER_PIPELINE_TOKEN_PATH -format=json | jq -r .data.value)

date
echo "MASTER PIPELINE TOKEN: ***${MASTER_PIPELINE_TOKEN: -4}"
vault token lookup $MASTER_PIPELINE_TOKEN | egrep '^expire'
echo

date
VAULT_DEPLOYER_TOKEN=$(vault read $VAULT_DEPLOYER_TOKEN_PATH -format=json | jq -r .data.value)
echo "VAULT_DEPLOYER TOKEN:  ***${VAULT_DEPLOYER_TOKEN: -4}"
vault token lookup $VAULT_DEPLOYER_TOKEN | egrep '^expire'
echo
