#!/bin/bash -e

NUMBER_OF_TRIGGER_JOBS=${1:-10}
SLEEP_BETWEEN_TRIGGERS=${2:-0}

DIR=$(dirname "${BASH_SOURCE[0]}") ; . $DIR/../init/env.sh
BASENAME=$(basename "${BASH_SOURCE[0]}")

TEST_PIPELINE=$ORG_SCOPE-$FUNC_SCOPE-platformtest-$ENVIRONMENT
TEST_JOB=master-pipeline/Set-And-Trigger-$TEST_PIPELINE
TEST_STATUS=/tmp/${BASENAME%%.sh}.status

rm -f $TEST_STATUS > /dev/null 2>&1

EXIT_STATUS=0

$DIR/../init/concourse-login.sh

for i in $(seq 1 $NUMBER_OF_TRIGGER_JOBS) ; do

  $DIR/../$INST/test-job.sh $TEST_JOB $TEST_STATUS & 

  sleep $SLEEP_BETWEEN_TRIGGERS
done

wait

$DIR/../init/concourse-logout.sh

cat $TEST_STATUS | awk '$1 != 0 {exit 1}'
