#!/bin/bash -e

DIR=$(dirname "${BASH_SOURCE[0]}")

export POSTGRES_HOST=${1:-$($DIR/../init/get-postgres-host.sh)}
export PGPASSWORD=$($DIR/../init/get-postgres-master-password.sh)

RELEASE=${1:-$(cat $DIR/../$INST/RELEASE)}
RELEASE_TEAM="release_$(echo $RELEASE | sed 's/\./_/g')"

CONCOURSE_RELEASE_TEAM=$(psql -h $POSTGRES_HOST \
                            -d atc -U master \
                            -c "SELECT COUNT (*) from teams where name='"$RELEASE_TEAM"'" \
                            -t)
CORRECT_RELEASE_FOUND=1

[ $CONCOURSE_RELEASE_TEAM -eq $CORRECT_RELEASE_FOUND ] && exit 0

exit 1
