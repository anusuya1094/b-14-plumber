#!/bin/bash -e

DIR=$(dirname "${BASH_SOURCE[0]}")

export POSTGRES_HOST=${1:-$($DIR/../init/get-postgres-host.sh)}
export PGPASSWORD=$($DIR/../init/get-postgres-master-password.sh)

TEST_VALUE=1

CONCOURSE_NUMBER_OF_RELEASE=$(psql -h $POSTGRES_HOST \
                            -d atc -U master \
                            -c "SELECT COUNT (*) from teams where name like 'release_%'" \
                            -t)

[ $CONCOURSE_NUMBER_OF_RELEASE -eq $TEST_VALUE ] && exit 0

exit 1
